<?php
define("USER", "root");
define("SERVER", "localhost");
define("BD", "store");
define("PASS", "03111997");