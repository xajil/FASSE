<?php
define("USER", "root");
define("SERVER", "localhost");
define("BD", "tecno_shop");
define("PASS", "");