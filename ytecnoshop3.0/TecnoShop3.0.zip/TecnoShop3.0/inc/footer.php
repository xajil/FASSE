<div class="ResForm"></div>
<div class="ResbeforeSend"></div>
<footer>
    <div class="container">
        <div class="row">
            <div class="col-sm-4">
                <h4 class="text-footer">Contactanos</h4>
                <a href="#" target="_blank">
                    <i class="fa fa-facebook" aria-hidden="true">&nbsp; Facebook </i> 
                </a><br>
                <a href="#" target="_blank">
                    <i class="fa fa-twitter" aria-hidden="true">&nbsp; Twitter </i>
                </a><br>
                <a href="#" target="_blank">
                    <i class="fa fa-youtube-play" aria-hidden="true">&nbsp; YouTube </i>
                </a><br>
                <a href="#" target="_blank">
                    <i class="fa fa-instagram" aria-hidden="true">&nbsp; Instagram </i>
                </a><br>
                <a href="#" target="_blank">
                    <i class="fa fa-map-marker" aria-hidden="true">&nbsp; Encuentranos </i>
                </a>
            </div>
            <div class="col-sm-4">
                <h4 class="text-footer">Porque elegirnos</h4>
                <p> 
                    ->Ofrecemos los mejores productos a los mejores precios.</br>
                    ->Amplia variedad de productos.</br>
                    ->Calidad carantizada</br>
                    Lorem ipsum dolor sit amet,adipisicing elit.</br>
                </p>
            </div>
            <div class="col-sm-4">
                <h4 class="text-footer" >Direccion</h4>
                <p style="color: #FFF">Solola, Guatemala</p>
                <p style="color: #FFF">adipisicing elit</p>
                <p style="font-size:20px" aria-hidden="true">  000 – 000000 / 000 – 000000</p>
                <p class="fa fa-mobile" style="font-size:20px"  aria-hidden="true">  00000000 / 0000000</p> <a href="#" target="_blank" style="color: #5bc0de">envianos_un_mensaje</a></br>
                E-mail: <a href="#" target="_blank" style="color: #5bc0de"> &nbsp; ejemplod@dominio.com</a>
            </div>
        </div>
    </div>
    <br><br><br>
    <h5 class="text-center tittles-pages-logo text-footer">TECNO SHOP &copy; 2021</h5>
</footer>
